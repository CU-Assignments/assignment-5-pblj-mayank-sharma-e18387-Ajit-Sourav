import java.util.ArrayList;
import java.util.Scanner;

public class SumIntegers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> numbers = new ArrayList<>();

        System.out.print("Enter numbers separated by spaces: ");
        String input = scanner.nextLine();
        String[] tokens = input.split(" ");

        int sum = 0;
        for (String token : tokens) {
            Integer num = Integer.parseInt(token); // Autoboxing
            numbers.add(num);
        }

        for (Integer num : numbers) {
            sum += num; // Unboxing
        }

        System.out.println("Sum of numbers: " + sum);
        scanner.close();
    }
}
