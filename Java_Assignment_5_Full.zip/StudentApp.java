import java.io.*;

public class StudentApp {
    public static void main(String[] args) {
        Student student = new Student(101, "John Doe", 3.8);

        // Serialization
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("student.ser"))) {
            out.writeObject(student);
            System.out.println("Student details saved successfully!");
        } catch (IOException e) {
            System.out.println("Error saving student: " + e.getMessage());
        }

        // Deserialization
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("student.ser"))) {
            System.out.println("\nReading from file...");
            Student deserializedStudent = (Student) in.readObject();
            System.out.println("Student ID: " + deserializedStudent.id);
            System.out.println("Student Name: " + deserializedStudent.name);
            System.out.println("Student GPA: " + deserializedStudent.gpa);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error reading student: " + e.getMessage());
        }
    }
}
